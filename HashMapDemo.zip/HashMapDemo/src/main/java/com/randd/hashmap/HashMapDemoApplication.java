package com.randd.hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HashMapDemoApplication {

	public static void main(String[] args) {
//		SpringApplication.run(HashMapDemoApplication.class, args);
		
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		
		hm.put(1,"Name1");
		hm.put(2,"Name2");
		hm.put(3,"Name3");
		hm.put(4,"Name4");
		hm.put(5,"Name5");
		
		System.out.println(hm);
		
		for (Integer key : hm.keySet()) {
			System.out.println("Key : "+key+"\tValue : "+hm.get(key));
		}
		
		System.out.println("\nHashMap size : "+hm.size());
		hm.clear();
		System.out.println("\nHashMap cleared "+hm);
		
		hm.put(15,"New Name A");
		hm.put(25,"New Name E");
		hm.put(5,"New Name C");
		hm.put(1,"New Name B");
		hm.put(50,"New Name D");
		System.out.println("\nNew Entries "+hm);
		System.out.println("\nHashMap Keys : "+hm.keySet());
		System.out.println("\nHashMap Values : "+hm.values());
		
		ArrayList<Integer> keys = new ArrayList<Integer>(hm.keySet()); 
		Collections.sort(keys);
		System.out.println("\nSort By Keys");
		for(int key : keys)
		{
			System.out.println("Key : "+key+"   Value : "+hm.get(key));
		}
		
		ArrayList<String> values = new ArrayList<String>(hm.values()); 		
		Collections.sort(values);
		System.out.println("\nSort By Values");
		for(String value : values)
		{
			System.out.println("Key : "+getKeyy(hm, value)+"   Value : "+value);
		}
	}
	
	public static Integer getKeyy(HashMap<Integer, String> hm, String value) {
		for(Integer index : hm.keySet())
		{
			if(hm.get(index)==value)
			{
				return index;
			}
		}
		return null;
	}
}
