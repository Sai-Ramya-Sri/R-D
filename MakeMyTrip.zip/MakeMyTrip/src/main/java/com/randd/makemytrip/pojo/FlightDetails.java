package com.randd.makemytrip.pojo;

import java.util.Comparator;
import java.util.Date;

public class FlightDetails {
	
	int flightNo;
	String airline, source, destination;
	Date departure, arrival;
	double cost;
	
	public FlightDetails() {
		
	}
	
	public FlightDetails(int flightNo, String airline, String source, String destination, Date departure,
			Date arrival, double cost) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.source = source;
		this.destination = destination;
		this.departure = departure;
		this.arrival = arrival;
		this.cost = cost;
	}
	
	
	public void setSource(String source) {
		this.source = source;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setDeparture(Date departureTime) {
		this.departure = departureTime;
	}

	public void setArrival(Date arrivalTime) {
		this.arrival = arrivalTime;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public int getFlightNo() {
		return flightNo;
	}

	public String getAirline() {
		return airline;
	}

	public String getSource() {
		return source;
	}

	public String getDestination() {
		return destination;
	}

	public Date getDepartureTime() {
		return departure;
	}

	public Date getArrivalTime() {
		return arrival;
	}

	public double getCost() {
		return cost;
	}

	@Override
	public String toString() {
		return "FlightDetails [flightNo=" + flightNo + ", airline=" + airline + ", source=" + source + ", destination="
				+ destination + ", departure=" + departure + ", arrival=" + arrival + ", cost=" + cost
				+ "]";
	}
	
	public static Comparator<FlightDetails> costComparator = new Comparator<FlightDetails>() {         
	    public int compare(FlightDetails fd1, FlightDetails fd2) {             
	      return (fd2.getCost() > fd1.getCost()? -1 :                     
	              (fd2.getCost() == fd1.getCost() ? 0 : 1));           
	    }     
	  };
	  
//	  public static Comparator<FlightDetails> timeComparator = new Comparator<FlightDetails>() {         
//		    public int compare(FlightDetails fd1, FlightDetails fd2) {
////		    	long flight1 = java.time.Duration.between(fd1.getArrivalTime(), fd1.getDepartureTime()).getSeconds();
//		    	long flight1 = fd1.getArrivalTime()-fd1.getDepartureTime();
//		    	long flight2 = fd2.getArrivalTime()-fd2.getDepartureTime();
//		      return (flight2 > flight1 ? -1 :                     
//		              (flight2 == flight1 ? 0 : 1));           
//		    }     
//		  };

	
	
}