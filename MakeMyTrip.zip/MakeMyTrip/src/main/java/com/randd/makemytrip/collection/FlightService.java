package com.randd.makemytrip.collection;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import com.randd.makemytrip.pojo.FlightDetails;

public class FlightService {
	
	ArrayList<FlightDetails> flightDetailsList = new ArrayList<FlightDetails>();
	
	public void addFlight(FlightDetails f) {
		flightDetailsList.add(f);
	}
	
	public ArrayList<FlightDetails> getAllFlights() {
		return flightDetailsList;
	}
	
	public FlightDetails getFlightByNo(int flightNo)
	{
		for( FlightDetails f : flightDetailsList) {
			if( f.getFlightNo() == flightNo ) {
				return f;
			}
		}
		throw new RuntimeException("Flight Does Not Exist");
	}
	
	public ArrayList<FlightDetails> removeFlightById(int flightNo)
	{
		for(FlightDetails f : flightDetailsList) {
			if(f.getFlightNo() == flightNo) {
				flightDetailsList.remove(f);
				return flightDetailsList;
			}
		}
		throw new RuntimeException("Flight Does Not Exist");
	}
	
	public ArrayList<FlightDetails> updateFlight(FlightDetails f) {
		
		for(FlightDetails f1 : flightDetailsList) {
			if(f1.getFlightNo() == f.getFlightNo()) {
				flightDetailsList.set(flightDetailsList.indexOf(f1), f);
				return flightDetailsList;
			}
		}
		throw new RuntimeException("Account Does Not Exist");
	}
	
	public static Date convertToDate(String string) throws ParseException
	{
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH);
		Date date = format.parse(string);
		return date;
	}
	
	public ArrayList<FlightDetails> sortByCost() {
		Collections.sort(flightDetailsList, FlightDetails.costComparator);
		return flightDetailsList;
	}
	
//	public ArrayList<FlightDetails> sortByTime() {
//		Collections.sort(flightDetailsList, FlightDetails.timeComparator);
//		return flightDetailsList;
//	}
	
	
	
	
	public static void main(String[] args) throws ParseException {
		
		FlightDetails f1 = new FlightDetails(1, "Airline1", "Source1", "Destination1", convertToDate("03/10/2018 18:13:47"), convertToDate("03/10/2018 20:15:56"),5000);
		FlightDetails f2 = new FlightDetails(2, "Airline2", "Source2", "Destination2", convertToDate("01/01/2018 01:01:01"), convertToDate("01/01/2018 05:05:05"), 9000);
		FlightDetails f3 = new FlightDetails(3, "Airline3", "Source3", "Destination3", convertToDate("01/10/2018 23:13:45"), convertToDate("02/10/2018 03:02:58"), 4000);
		FlightDetails f4 = new FlightDetails(4, "Airline4", "Source4", "Destination4", convertToDate("05/06/2018 20:20:00"), convertToDate("05/05/2018 22:15:30"), 8000);
		FlightDetails f5 = new FlightDetails(5, "Airline5", "Source5", "Destination5", convertToDate("08/07/2018 14:13:47"), convertToDate("08/07/2018 15:15:56"), 3000);
		FlightDetails f6 = new FlightDetails(6, "Airline6", "Source6", "Destination6", convertToDate("09/12/2018 22:13:47"), convertToDate("10/12/2018 00:15:56"), 10000);
		
		FlightService fs = new FlightService();
		fs.addFlight(f1);
		fs.addFlight(f2);
		fs.addFlight(f3);
		fs.addFlight(f4);
		fs.addFlight(f5);
		fs.addFlight(f6);
		
		System.out.println("All Flights");
		for(FlightDetails f : fs.getAllFlights())
		{
			System.out.println(f);
		}
		
		System.out.println("\nRemove Flight No 2");
		fs.removeFlightById(2);
		System.out.println("All Flights");
		for(FlightDetails f : fs.getAllFlights())
		{
			System.out.println(f);
		}
		
		System.out.println("\nGet Flight Number 4");
		System.out.println(fs.getFlightByNo(4));
		
		System.out.println("\nUpdate flight Number 3(Source), 4(Destination), 5(Departure to Mon Jul 09 14:15:47 IST 2018), 6(Arrival to Tue Dec 11 00:15:56 IST 2018)");
		FlightDetails f7 = fs.getFlightByNo(3);
		f7.setSource("New Source");
		fs.updateFlight(f7);
		f7 = fs.getFlightByNo(4);
		f7.setDestination("New Destination");
		fs.updateFlight(f7);
		f7 = fs.getFlightByNo(5);
		f7.setDeparture(convertToDate("09/07/2018 14:15:47"));
		fs.updateFlight(f7);
		f7 = fs.getFlightByNo(6);
		f7.setArrival(convertToDate("11/12/2018 00:15:56"));
		fs.updateFlight(f7);
		System.out.println("All Flights");
		for(FlightDetails f : fs.getAllFlights())
		{
			System.out.println(f);
		}
		
		System.out.println("\nSort(Cheapest Flight first)");
		for(FlightDetails f : fs.sortByCost())
		{
			System.out.println(f);
		}
		
//		System.out.println("\nSort(Fastest first)");
//		for(FlightDetails f : fs.sortByTime())
//		{
//			System.out.println(f);
//		}
		
			
		
	}
}




/*collection -
add
remove
update - 4
sort - 	fastest, cheapest,
		section --> morning, noon, night, latenight 6to12*/