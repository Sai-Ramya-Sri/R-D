package com.capgemini.randd.java8.client;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.capgemini.randd.java8.model.Student;

public class ClientTest {
	
	private final static PrintStream myOut = new PrintStream(System.out);
	
	public static void main(String[] args) {
		
		List<Student> studentList = new ArrayList<>();
		studentList.add(new Student("Ramya", 21));
		studentList.add(new Student("Tanya", 22));
		studentList.add(new Student("Angshuman", 22));
		Collections.sort(studentList);
//		myOut.println("Hi");		
//		studentList.forEach(System.out::println);
		studentList.forEach(ClientTest.myOut::println);
		
		Runnable runnable = () -> System.out.println("\nThread created using Lambda");
		Thread thread = new Thread(runnable);
		thread.start();
		
	}
	
	
}