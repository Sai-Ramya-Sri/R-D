package com.capgemini.randd.java8.model;

public class Student implements Comparable<Student>{
	
	private String name;
	private int age;
	
	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + "]";
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public Student(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public int compareTo(Student student) {
		return this.getName().compareTo(student.getName());
	}
}
