package com.capgemini.randd.lambda;

public interface MyInterface1 {
	
	public abstract void method1();
}
