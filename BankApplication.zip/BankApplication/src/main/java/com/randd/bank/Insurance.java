package com.randd.bank;

public interface Insurance {
	
	public String getInsuranceName();
	public double getInsuranceAmount();
	public String getInsuranceHolderName();
	
}