package com.randd.bank;

import java.util.HashSet;
//import java.util.Collections;

public class BankAccountListVersion4 {
	
	HashSet<BankAccount> bankAccountList = new HashSet<BankAccount>();
	int index = 0;
	
	
	public void addAccount(BankAccount ba)
	{
		bankAccountList.add(ba);
	}
	
	public HashSet<BankAccount> getAllAccounts() {
		return bankAccountList;
	}
	
	public BankAccount getAccountById(int accountId)
	{
		
		//return bankAccountList.get(accountId);
		for( BankAccount b : bankAccountList) {
			if(b.getAccountNo()==accountId) {
				return b;
			}
		}
		throw new RuntimeException("Account Does Not Exist");
//		return null;
	}
	
//	public HashSet<BankAccount> updateAccount(BankAccount ba) {
//		
//		for(BankAccount b : bankAccountList) {
//			if(b.getAccountNo()==ba.getAccountNo()) {
//				bankAccountList.set(bankAccountList.indexOf(b), ba);
//				return bankAccountList;
//			}
//		}
//		throw new RuntimeException("Account Does Not Exist");
//	}
	
	public HashSet<BankAccount> deleteAccountById(int accountNo)
	{
		for(BankAccount b : bankAccountList) {
			if(b.getAccountNo()==accountNo) {
				bankAccountList.remove(b);
				return bankAccountList;
			}
		}
		throw new RuntimeException("Account Does Not Exist");
	}
	
//	public HashSet<BankAccount> sortByBalance() {
//		Collections.sort(bankAccountList, BankAccount.balanceComparator);
//		return bankAccountList;
//	}
//	
//	public HashSet<BankAccount> sortByName() {
//		Collections.sort(bankAccountList, BankAccount.nameComparator);
//		return bankAccountList;
//	}
	
	public static void main(String[] args) {
		
		BankAccountListVersion4 bl = new BankAccountListVersion4();
		
		BankAccount ba = new BankAccount("BA1",45464);
		BankAccount ba0 = new BankAccount("BA2",95645544);
		bl.addAccount(ba);
		bl.addAccount(ba0);
		
		BankAccount ba2 = new BankAccount("V",300000000);
		bl.addAccount(ba2);
		
		BankAccount ba3 = new BankAccount("My Name",600000);
		bl.addAccount(ba3);
		
		BankAccount ba4 = new BankAccount("BA3",545344);
		bl.addAccount(ba4);
		
		BankAccount ba5 = new BankAccount();
		bl.addAccount(ba5);
		
		System.out.println("Accounts Added");
		HashSet<BankAccount> accountList = bl.getAllAccounts();
		System.out.println("All accounts");
		for( BankAccount b : accountList) {
			if(b!=null)
				System.out.println(b);
		}
		
		System.out.println("\nGet account by Account Number(Account Number = 4)");
		BankAccount b = bl.getAccountById(4);
		System.out.println(b);
		
//		System.out.println("\nUpdate account (Account Number = 5)");
//		BankAccount ba6 = bl.getAccountById(5);
//		ba6.setAccountHolderName("New Account Holder Name");
//		System.out.println("All Accounts");
//		for( BankAccount b1 : bl.updateAccount(ba6)) {
//			if(b1!=null)
//				System.out.println(b1);
//		}
				
		System.out.println("\nDelete Account (Account Number = 2)\nAll Accounts");
		for( BankAccount b1 : bl.deleteAccountById(2)) {
				System.out.println(b1);
		}
		
//		System.out.println("\nSort By Balance in descending order");
//		for( BankAccount b1 : bl.sortByBalance()) {
//			System.out.println(b1);
//		}
//		
//		System.out.println("\nSort By Account Holder Name");
//		for( BankAccount b1 : bl.sortByName()) {
//			System.out.println(b1);
//		}
		
		
		BankAccount ba9 = new BankAccount("New",2554);
		bl.addAccount(ba9);
		
		System.out.println("Accounts Added");
		accountList = bl.getAllAccounts();
		System.out.println("All accounts");
		for( BankAccount b9 : accountList) {
			if(b!=null)
				System.out.println(b9);
		}
		
		
		
	}
	
}
