package com.randd.bank;

public class CurrentAccount extends BankAccount {
	
	public CurrentAccount() {
		accountBalance = 5000;
	}
	
	public void withdraw(double amount) {
		if(accountBalance-amount>=5000) {
			accountBalance-=amount;
		}
		else {
			System.out.println("Insufficient funds");
		}
	}
	
	@Override
	public String toString() {
		return "CurrentAccount [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName
				+ ", accountBalance=" + accountBalance + "]";
	}
	
}
