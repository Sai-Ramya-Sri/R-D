package com.randd.bank;


public class BankAccountList {
	
	BankAccount[] bankAccountList;
	int index = 0;
	
	public BankAccountList(int size) {
		bankAccountList = new BankAccount[size];
	}
	
	public BankAccountList() {
		bankAccountList = new BankAccount[100];
	}
	
	public void addAccount(BankAccount ba)
	{
//		for(int index=0; index<bankAccountList.length; index++)
//		{
//			if(bankAccountList[index] == null)
//			{
//				bankAccountList[index] = ba;
//				return;
//			}
//		}
		
		bankAccountList[index++] = ba;
	}
	
	public BankAccount[] getAllAccounts() {
		return bankAccountList;
	}
	
	public BankAccount getAccountById(int accountId)
	{
		for( BankAccount b : bankAccountList) {
			if(b.getAccountNo()==accountId) {
				return b;
			}
		}
		throw new RuntimeException("Account Does Not Exist");
//		return null;
	}
	
	public BankAccount[] updateAccount(BankAccount ba) {
		
		for(int index=0; index<bankAccountList.length; index++) {
			if(bankAccountList[index].getAccountNo()==ba.getAccountNo()) {
				bankAccountList[index] = ba;
				return bankAccountList;
			}
		}
		throw new RuntimeException("Account Does Not Exist");
	}
	
	public BankAccount[] deleteAccountById(int accountNo)
	{
		int newindex;
		for(int index=0; index<bankAccountList.length-1 ; index++) {
			if(bankAccountList[index].getAccountNo() == accountNo) {
				for(newindex = index; bankAccountList[index+1]!=null && newindex<bankAccountList.length-1; newindex++)
				{
					bankAccountList[newindex] = bankAccountList[newindex+1];
				}
				bankAccountList[newindex] = null;
				return bankAccountList;
			}
		}
		throw new RuntimeException("Account Does Not Exist");
	}
	
	public static void main(String[] args) {
		
		BankAccountList bl = new BankAccountList(5);
		
		BankAccount ba = new BankAccount();
		BankAccount ba0 = new BankAccount();
		bl.addAccount(ba);
		bl.addAccount(ba0);
		
		BankAccount ba1 = new BankAccount("My Name",6000000);
		bl.addAccount(ba1);
		
		BankAccount ba2 = new BankAccount();
		bl.addAccount(ba2);
		
		BankAccount ba3 = new BankAccount();
		bl.addAccount(ba3);
		
		System.out.println("\nAccounts Added");
		BankAccount[] accountList = bl.getAllAccounts();
		System.out.println("All accounts");
		for( BankAccount b : accountList) {
			if(b!=null)
				System.out.println(b);
		}
		
		System.out.println("\nGet account by id(id = 3)");
		BankAccount b = bl.getAccountById(3);
		System.out.println(b);
		
		System.out.println("\nUpdate account (id = 4)");
		BankAccount ba4 = bl.getAccountById(4);
		ba4.setAccountHolderName("New Account Holder Name");
		System.out.println("All Accounts");
		for( BankAccount b1 : bl.updateAccount(ba4)) {
			if(b1!=null)
				System.out.println(b1);
		}
				
		System.out.println("Delete Account (id = 3)\nAll Accounts");
		for( BankAccount b1 : bl.deleteAccountById(3)) {
				System.out.println(b1);
		}
		
	}
	
}
