package com.randd.bank;

public class Customer {
	
	
public static void main(String[] args) {
		
	
//		BankAccount acc; //structure of BankAccount is created.
//		acc = new SavingsAccount2(); //acc has the structure of BankAcoount with the implementation of SavingsAccount.
//		System.out.println(acc);
		
		SavingsAccount2 sa = new SavingsAccount2();
		sa.setAccountHolderName("Savings Account Holder");
//		System.out.println(sa);
		
		CurrentAccount2 ca = new CurrentAccount2();
		ca.setAccountHolderName("Current Account Holder");
//		System.out.println(ca);
		
		System.out.println("Insurance Name : "+sa.getInsuranceName()+"\nInsurance Holder Name : "+sa.getInsuranceHolderName()+"\nInsrance Amount : "+sa.getInsuranceAmount());
		System.out.println("\n\nInsurance Name : "+ca.getInsuranceName()+"\nInsurance Holder Name : "+ca.getInsuranceHolderName()+"\nInsrance Amount : "+ca.getInsuranceAmount());
	}
	
}
