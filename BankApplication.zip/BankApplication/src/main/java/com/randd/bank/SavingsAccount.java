package com.randd.bank;

public class SavingsAccount {
	
	String accountType;
	
	public SavingsAccount() {
		this.accountType = "salaried";
	}
	public SavingsAccount(String accountType) {
		super();
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "SavingsAccount [accountType=" + accountType + ", toString()=" + super.toString() + "]";
	}
	
}
