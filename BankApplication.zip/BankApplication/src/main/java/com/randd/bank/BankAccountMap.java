package com.randd.bank;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class BankAccountMap {
	
	Map<Integer, BankAccount> bankAccountMap;
	int index = 0;
	
	public BankAccountMap() {
		bankAccountMap = new TreeMap<Integer, BankAccount>();
	}
	
	public void addBankAccountForEmployee(int empId, BankAccount ba)
	{
		bankAccountMap.put(empId, ba);
	}
	
	public Set<Integer> getAllEmployeeId() {
		return bankAccountMap.keySet();
	}
	
	public Collection<BankAccount> getAllBankAccounts() {
		return bankAccountMap.values();
	}
	
	public Set<Entry<Integer, BankAccount>> getAllEmployeeDetails() {
		return bankAccountMap.entrySet();
	}	
}