package com.randd.bank;

import java.util.Comparator;

/** Documentation based comment
 * 
 * @author skappaga
 * @since 03-10-2018
 * 
 */


public class BankAccount implements Comparable<BankAccount>{
	
	int accountNo;
	String accountHolderName;
	double accountBalance;
	static int autoAccountNoGen;
	
//	{
//		System.out.println("Init");
//	}
//	
//	static {
//		System.out.println("Static");
//	}
	
	public BankAccount() {
		accountNo = ++autoAccountNoGen;
		accountHolderName = "Unknown";
		accountBalance = 0;
	}
	
	public BankAccount(String accountHolderName, double accountBalance) {
		accountNo = ++autoAccountNoGen;
		this.accountHolderName = accountHolderName;
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", accountBalance="
				+ accountBalance + "]";
	}
	
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	
	public static int getAutoAccountNoGen() {
		return autoAccountNoGen;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

//	public abstract void withdraw(double amount);
	
	public void deposit(double amount)
	{
		if(amount>0) {
			accountBalance+=amount;
		}
	}
	
	
	public static Comparator<BankAccount> balanceComparator = new Comparator<BankAccount>() {         
	    public int compare(BankAccount ba1, BankAccount ba2) {             
	      return (ba2.getAccountBalance() < ba1.getAccountBalance()? -1 :                     
	              (ba2.getAccountBalance() == ba1.getAccountBalance() ? 0 : 1));           
	    }     
	  };
	  
	  public static Comparator<BankAccount> nameComparator = new Comparator<BankAccount>() {         
		  public int compare(BankAccount ba1, BankAccount ba2) {             
		      return (int) (ba1.getAccountHolderName().compareTo(ba2.getAccountHolderName()));         
		  }
	  };
		  
		  
	public int compareTo(BankAccount acc) {
		return this.getAccountNo()-acc.getAccountNo();
	}  
	
	
}