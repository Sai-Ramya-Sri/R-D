package com.randd.bank;

public class SavingsAccount2 extends BankAccount implements Insurance {
	
	public String getInsuranceName() {
		return "Insurance_Savings 1";
	}
	
	public double getInsuranceAmount() {
		return 6000000;
	}
	
	public String getInsuranceHolderName() {
		return this.getAccountHolderName();
	}
	
}
