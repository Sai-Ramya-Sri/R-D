package com.randd.bank;

public class CurrentAccount2 extends CurrentAccount implements Insurance {
	
	public String getInsuranceName() {
		return "Insurance_Current 1";
	}

	public double getInsuranceAmount() {
		return 5000000;
	}

	public String getInsuranceHolderName() {
		return this.getAccountHolderName();
	}
	
}
